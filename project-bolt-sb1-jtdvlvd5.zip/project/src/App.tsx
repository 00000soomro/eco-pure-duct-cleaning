import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Pricing from './components/Pricing';
import About from './components/About';
import ServiceAreas from './components/ServiceAreas';
import Reviews from './components/Reviews';
import CTA from './components/CTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Header />
      <main className="flex-1">
        <Hero />
        <div className="px-4 sm:px-6 lg:px-40 flex flex-1 justify-center py-16">
          <div className="max-w-[960px] flex-1">
            <Services />
            <Pricing />
            <About />
            <ServiceAreas />
            <Reviews />
            <CTA />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;