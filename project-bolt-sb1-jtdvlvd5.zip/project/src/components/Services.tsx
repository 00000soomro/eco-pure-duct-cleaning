import React from 'react';
import { Home, Briefcase, Wind, FlaskConical, Waves, Filter, Leaf } from 'lucide-react';

const services = [
  {
    icon: Home,
    title: "Eco-Friendly Residential Cleaning",
    description: "Our comprehensive eco-friendly residential service removes dust, allergens, and contaminants from your home's ductwork using green cleaning solutions, improving indoor air quality for you and your family."
  },
  {
    icon: Briefcase,
    title: "Green Commercial Solutions",
    description: "We provide tailored eco-friendly air duct cleaning solutions for businesses of all sizes, ensuring a healthy and productive environment for your employees and customers using sustainable practices."
  },
  {
    icon: Wind,
    title: "Eco Dryer Vent Cleaning",
    description: "Prevent fire hazards and improve your dryer's efficiency with our eco-friendly vent cleaning service. We remove lint buildup using green methods, ensuring safety and performance."
  },
  {
    icon: FlaskConical,
    title: "Pure Air Quality Testing",
    description: "Our advanced air quality testing identifies pollutants in your home or office. We provide detailed reports and eco-friendly recommendations for improving your indoor air naturally."
  },
  {
    icon: Waves,
    title: "Green HVAC System Cleaning",
    description: "Boost your HVAC system's efficiency and lifespan with our eco-friendly furnace and coil cleaning service, ensuring optimal performance and energy savings with sustainable methods."
  },
  {
    icon: Leaf,
    title: "Eco Filter Maintenance",
    description: "We offer regular eco-friendly filter replacement and maintenance services using sustainable materials to keep your HVAC system running smoothly and your air clean year-round."
  }
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-12">
      <h2 className="text-center text-slate-900 text-4xl font-bold leading-tight tracking-[-0.015em] mb-12">
        Our Services
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {services.map((service, index) => {
          const IconComponent = service.icon;
          return (
            <div 
              key={index}
              className="flex flex-col gap-4 p-6 rounded-lg border border-slate-200 bg-white shadow-sm hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 group"
            >
              <div className="flex items-center gap-4">
                <IconComponent className="w-10 h-10 text-emerald-600 group-hover:scale-110 transition-transform duration-300" />
                <h3 className="text-slate-900 text-xl font-bold leading-tight group-hover:text-emerald-600 transition-colors duration-300">
                  {service.title}
                </h3>
              </div>
              <p className="text-slate-600 text-base leading-relaxed">
                {service.description}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default Services;