import React from 'react';

const cities = [
  'Barrie', 'Belleville', 'Brampton', 'Brantford', 'Brockville', 'Burlington',
  'Cambridge', 'Clarence–Rockland', 'Cornwall', 'Dryden', 'Elliot Lake', 'Greater Sudbury',
  'Guelph', 'Hamilton', 'Kawartha Lakes', 'Kenora', 'Kingston', 'Kitchener',
  'London', 'Markham', 'Mississauga', 'Niagara Falls', 'North Bay', 'Orillia',
  'Oshawa', 'Ottawa', 'Owen Sound', 'Pembroke', 'Peterborough', 'Pickering',
  'Port Colborne', 'Quinte West', 'Richmond Hill', 'Sarnia', 'Sault Ste. Marie', 'St. Catharines',
  'St. Thomas', 'Stratford', 'Temiskaming Shores', 'Thorold', 'Thunder Bay', 'Timmins',
  'Toronto', 'Vaughan', 'Waterloo', 'Welland', 'Windsor', 'Woodstock'
];

const ServiceAreas: React.FC = () => {
  return (
    <section id="service-areas" className="py-16 bg-gradient-to-br from-slate-50 to-emerald-50 rounded-xl">
      <h2 className="text-center text-slate-900 text-4xl font-bold leading-tight tracking-[-0.015em] mb-10">
        Service Areas – Ontario
      </h2>
      
      {/* Featured Cities */}
      <div className="max-w-6xl mx-auto mb-12">
        <h3 className="text-center text-slate-700 text-xl font-semibold mb-8">Major Service Areas</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          {['Toronto', 'Ottawa', 'Hamilton', 'London'].map((city, index) => (
            <div 
              key={index}
              className="bg-white rounded-lg shadow-md p-6 text-center hover:shadow-lg hover:bg-emerald-50 transition-all duration-300 transform hover:-translate-y-1 border-2 border-emerald-100"
            >
              <h4 className="text-lg font-bold text-slate-900 mb-2">{city}</h4>
              <p className="text-sm text-emerald-600 font-medium">& Surrounding Areas</p>
            </div>
          ))}
        </div>
      </div>

      {/* All Cities Grid */}
      <div className="max-w-6xl mx-auto">
        <h3 className="text-center text-slate-700 text-xl font-semibold mb-8">All Ontario Cities We Serve</h3>
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 text-center">
        {cities.map((city, index) => (
            <div 
            key={index}
              className="text-slate-700 text-sm font-medium leading-normal hover:text-emerald-600 hover:bg-emerald-50 transition-all duration-200 cursor-pointer py-3 px-2 rounded-lg border border-transparent hover:border-emerald-200 hover:shadow-sm"
            >
              {city}
            </div>
        ))}
          </div>
        </div>
      </div>
      
      <div className="text-center mt-8">
        <p className="text-slate-600 text-base font-medium mb-4">
          Don't see your location? We likely serve your area too!
        </p>
        <p className="text-emerald-600 text-sm font-medium">
          Contact us to confirm service availability in your specific location.
      </p>
      </div>
    </section>
  );
};

export default ServiceAreas;