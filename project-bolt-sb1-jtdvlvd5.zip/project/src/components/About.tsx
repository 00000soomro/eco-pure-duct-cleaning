import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-12">
      <h2 className="text-center text-slate-900 text-4xl font-bold leading-tight tracking-[-0.015em] mb-10">
        About Us
      </h2>
      <p className="text-slate-900 text-lg text-center font-normal leading-relaxed max-w-3xl mx-auto">
        At EcoPure Duct Cleaning, we are committed to providing exceptional eco-friendly air duct cleaning services in Ontario. Our mission is to improve the health and well-being of our customers and the environment by ensuring their indoor air quality is at its best using sustainable, green cleaning methods. With years of experience and a focus on both customer satisfaction and environmental responsibility, we are the trusted choice for clean, pure air solutions.
      </p>
    </section>
  );
};

export default About;