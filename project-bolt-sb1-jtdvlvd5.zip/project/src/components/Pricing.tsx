import React from 'react';

const pricingData = [
  { service: "Residential Air Duct Cleaning", priceRange: "$199 - $499+", toronto: "$199+", ottawa: "$229+" },
  { service: "Furnace Cleaning", priceRange: "$149 - $299", toronto: "$149", ottawa: "$159" },
  { service: "Dryer Vent Cleaning", priceRange: "$99 - $199", toronto: "$99", ottawa: "$109" },
  { service: "Commercial Duct Cleaning", priceRange: "Custom Quote Required", toronto: "Custom Quote", ottawa: "Custom Quote" },
  { service: "Air Quality Testing", priceRange: "$150 - $400", toronto: "$150", ottawa: "$165" },
  { service: "Filter Replacement Service", priceRange: "$79 - $149 per visit", toronto: "$79 per visit", ottawa: "$89 per visit" },
  { service: "Sanitization & Deodorizing", priceRange: "$89 - $179", toronto: "$89", ottawa: "$99" }
];

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-12">
      <h2 className="text-center text-slate-900 text-4xl font-bold leading-tight tracking-[-0.015em] mb-10">
        Ontario Pricing
      </h2>
      <div className="overflow-x-auto rounded-lg border border-solid border-slate-200 bg-white shadow-lg">
        <table className="w-full text-left text-slate-900">
          <thead className="bg-slate-100 text-sm font-bold border-b border-slate-200">
            <tr>
              <th className="p-4 w-1/3">Service</th>
              <th className="p-4">Price Range (CAD)</th>
              <th className="p-4">Toronto & GTA</th>
              <th className="p-4">Ottawa & Surrounding</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {pricingData.map((row, index) => (
              <tr key={index} className="hover:bg-slate-50 transition-colors duration-200">
                <td className="p-4 font-medium">{row.service}</td>
                <td className="p-4">{row.priceRange}</td>
                <td className="p-4">{row.toronto}</td>
                <td className="p-4">{row.ottawa}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-center text-sm text-slate-500 mt-4 px-4">
        *All prices are estimates. Final cost may vary based on the size of the property, system complexity, and specific requirements. Travel surcharges may apply for locations outside of Toronto and Ottawa city limits. Contact us for a detailed and firm quote.
      </p>
    </section>
  );
};

export default Pricing;