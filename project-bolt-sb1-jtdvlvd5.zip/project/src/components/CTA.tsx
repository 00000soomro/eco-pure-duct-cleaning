import React, { useState } from 'react';
import { Phone, Mail, MapPin, Leaf, Clock, Award, Shield, CheckCircle } from 'lucide-react';
import PhoneModal from './PhoneModal';

const CTA: React.FC = () => {
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const phoneNumber = '647-317-4194';

  return (
    <>
      <section id="contact-info" className="py-20 bg-gradient-to-br from-emerald-50 to-blue-50 rounded-lg my-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Leaf className="w-12 h-12 text-emerald-600" />
          </div>
          <h2 className="text-slate-900 text-4xl font-bold leading-tight tracking-[-0.015em] mb-6">
            Contact EcoPure Today!
          </h2>
          <p className="text-slate-700 text-lg font-normal leading-relaxed max-w-2xl mx-auto">
            Ready to breathe cleaner air? Get in touch with Ontario's premier eco-friendly air duct cleaning service.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Contact Information */}
          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="text-center mb-6">
              <Phone className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Call Us Now</h3>
              <button 
                onClick={() => setIsPhoneModalOpen(true)}
                className="text-2xl font-bold text-emerald-600 hover:text-emerald-700 transition-colors"
              >
                (647) 317-4194
              </button>
              <p className="text-slate-600 mt-2">Available 24/7 for emergencies</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="text-center mb-6">
              <Mail className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Email Us</h3>
              <a 
                href="mailto:info@ecopureductcleaning.ca" 
                className="text-xl font-semibold text-emerald-600 hover:text-emerald-700 transition-colors"
              >
                info@ecopureductcleaning.ca
              </a>
              <p className="text-slate-600 mt-2">We respond within 2 hours</p>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
            <div className="text-center mb-6">
              <Clock className="w-12 h-12 text-emerald-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Business Hours</h3>
              <div className="text-slate-700 space-y-1">
                <p><span className="font-semibold">Mon-Fri:</span> 8:00 AM - 6:00 PM</p>
                <p><span className="font-semibold">Saturday:</span> 9:00 AM - 4:00 PM</p>
                <p><span className="font-semibold">Sunday:</span> Emergency Only</p>
              </div>
            </div>
          </div>
        </div>

        {/* Why Choose EcoPure Section */}
        <div className="bg-gradient-to-r from-emerald-600 to-blue-600 text-white rounded-xl shadow-lg p-8 mb-8">
          <h3 className="text-3xl font-bold text-center mb-8">Why Choose EcoPure?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <Leaf className="w-12 h-12 mx-auto mb-3" />
              <h4 className="font-bold mb-2">100% Eco-Friendly</h4>
              <p className="text-sm opacity-90">Green products safe for your family</p>
            </div>
            <div className="text-center">
              <Award className="w-12 h-12 mx-auto mb-3" />
              <h4 className="font-bold mb-2">Certified Technicians</h4>
              <p className="text-sm opacity-90">Licensed & insured professionals</p>
            </div>
            <div className="text-center">
              <Shield className="w-12 h-12 mx-auto mb-3" />
              <h4 className="font-bold mb-2">Satisfaction Guarantee</h4>
              <p className="text-sm opacity-90">100% money-back guarantee</p>
            </div>
            <div className="text-center">
              <CheckCircle className="w-12 h-12 mx-auto mb-3" />
              <h4 className="font-bold mb-2">Same Day Service</h4>
              <p className="text-sm opacity-90">Available for urgent needs</p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <button 
            onClick={() => setIsPhoneModalOpen(true)}
            className="bg-emerald-600 text-white py-4 px-8 rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            Call Now for Free Consultation
          </button>
        </div>
      </div>
      </section>
      
      <PhoneModal 
        isOpen={isPhoneModalOpen}
        onClose={() => setIsPhoneModalOpen(false)}
        phoneNumber={phoneNumber}
      />
    </>
  );
};

export default CTA;