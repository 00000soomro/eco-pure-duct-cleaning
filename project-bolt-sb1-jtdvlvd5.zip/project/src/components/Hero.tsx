import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[600px] flex items-center justify-center text-white overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transform scale-105 transition-transform duration-700 hover:scale-110"
        style={{
          backgroundImage: `url("https://images.pexels.com/photos/209251/pexels-photo-209251.jpeg?auto=compress&cs=tinysrgb&w=1600")`
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/70 to-blue-900/50" />
      <div className="relative z-10 flex flex-col items-center gap-6 text-center px-4 sm:px-10 max-w-4xl mx-auto">
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight tracking-[-0.033em] animate-fade-in-up">
          Breathe Clean with EcoPure Duct Cleaning
        </h1>
        <p className="text-lg sm:text-xl font-normal leading-normal max-w-2xl opacity-90 animate-fade-in-up animation-delay-300">
          Ontario's eco-friendly air duct cleaning service, ensuring your home's air is pure and healthy. Experience the difference with our green, professional cleaning solutions.
        </p>
        <button 
          onClick={() => {
            const contactInfo = document.getElementById('contact-info');
            if (contactInfo) {
              contactInfo.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-md h-12 px-6 bg-emerald-600 text-white text-base font-bold leading-normal tracking-[0.015em] hover:bg-emerald-700 transition-all duration-300 transform hover:scale-105 animate-fade-in-up animation-delay-600 shadow-lg hover:shadow-xl"
        >
          <span className="truncate">Contact Us Today</span>
        </button>
      </div>
    </section>
  );
};

export default Hero;