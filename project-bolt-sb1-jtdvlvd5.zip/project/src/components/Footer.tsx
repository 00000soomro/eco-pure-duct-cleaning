import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="border-t border-solid border-slate-200 bg-white">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-6">
          <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2">
            <a className="text-slate-500 text-sm font-normal leading-normal hover:text-emerald-600 transition-colors duration-200" href="#contact">
              Contact Us
            </a>
            <a className="text-slate-500 text-sm font-normal leading-normal hover:text-emerald-600 transition-colors duration-200" href="#privacy">
              Privacy Policy
            </a>
            <a className="text-slate-500 text-sm font-normal leading-normal hover:text-emerald-600 transition-colors duration-200" href="#terms">
              Terms of Service
            </a>
          </nav>
          <p className="text-slate-500 text-sm font-normal leading-normal">
            © 2024 EcoPure Duct Cleaning. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;