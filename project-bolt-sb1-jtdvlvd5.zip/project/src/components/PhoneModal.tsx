import React from 'react';
import { Phone, X } from 'lucide-react';

interface PhoneModalProps {
  isOpen: boolean;
  onClose: () => void;
  phoneNumber: string;
}

const PhoneModal: React.FC<PhoneModalProps> = ({ isOpen, onClose, phoneNumber }) => {
  if (!isOpen) return null;

  const handleCall = () => {
    window.open(`tel:${phoneNumber}`, '_self');
    onClose();
  };

  const formatPhoneNumber = (phone: string) => {
    const cleaned = phone.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return phone;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full mx-4 transform transition-all duration-300 scale-100">
        <div className="relative p-8">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-emerald-600" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Call EcoPure</h3>
            <p className="text-slate-600">Ready to improve your air quality?</p>
          </div>

          {/* Phone number display */}
          <div className="bg-emerald-50 rounded-xl p-6 mb-6 text-center">
            <p className="text-sm text-emerald-700 font-medium mb-2">Call us now at:</p>
            <p className="text-3xl font-bold text-emerald-800 tracking-wide">
              {formatPhoneNumber(phoneNumber)}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleCall}
              className="flex-1 bg-emerald-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-emerald-700 transition-all duration-200 transform hover:scale-105 flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Call Now
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg font-semibold hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
          </div>

          {/* Additional info */}
          <div className="mt-6 text-center">
            <p className="text-sm text-slate-500">
              Available Monday - Friday, 8 AM - 6 PM
            </p>
            <p className="text-sm text-slate-500">
              Emergency services available 24/7
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhoneModal;