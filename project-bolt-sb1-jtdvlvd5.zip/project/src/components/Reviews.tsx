import React from 'react';
import { Star } from 'lucide-react';

const reviews = [
  {
    name: "John D.",
    location: "Toronto, ON",
    rating: 5,
    review: "Fantastic eco-friendly service! The air in our home has never felt cleaner. The technicians were professional and used green cleaning products. Highly recommend EcoPure!"
  },
  {
    name: "Samantha K.",
    location: "Ottawa, ON",
    rating: 4,
    review: "Great eco-friendly job on our dryer vent. The team was punctual and did a thorough green cleaning. I can already notice the difference in drying time and feel good about the environmental impact."
  },
  {
    name: "Mike R.",
    location: "Hamilton, ON",
    rating: 5,
    review: "Our office building's air quality has improved dramatically with EcoPure's green cleaning methods. The commercial service was top-notch, with minimal disruption to our workday."
  },
  {
    name: "Linda H.",
    location: "London, ON",
    rating: 5,
    review: "I was suffering from allergies, and after EcoPure cleaned our ducts with their eco-friendly methods, my symptoms have reduced significantly. Thank you for the pure, fresh air!"
  },
  {
    name: "Tom B.",
    location: "Windsor, ON",
    rating: 4,
    review: "Solid eco-friendly service. The team explained their green cleaning process clearly. I'm happy with the results and love that they use environmentally safe products."
  },
  {
    name: "Jessica W.",
    location: "Mississauga, ON",
    rating: 5,
    review: "The air quality testing was very insightful. The follow-up eco-friendly cleaning service was excellent. I feel much better about the pure air my family is breathing and the environmental impact."
  }
];

const Reviews: React.FC = () => {
  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`w-4 h-4 ${index < rating ? 'text-emerald-600 fill-current' : 'text-slate-300'}`}
      />
    ));
  };

  return (
    <section className="py-12">
      <h2 className="text-center text-slate-900 text-4xl font-bold leading-tight tracking-[-0.015em] mb-10">
        Customer Honest Reviews – Ontario
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {reviews.map((review, index) => (
          <div 
            key={index}
            className="flex flex-col gap-4 bg-white p-6 rounded-lg border border-slate-200 shadow-sm hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="flex items-start gap-4">
              <div className="flex-1">
                <p className="text-slate-900 text-base font-bold leading-normal">{review.name}</p>
                <p className="text-slate-500 text-sm font-normal leading-normal">{review.location}</p>
              </div>
              <div className="flex gap-0.5">
                {renderStars(review.rating)}
              </div>
            </div>
            <p className="text-slate-900 text-base font-normal leading-relaxed">
              "{review.review}"
            </p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Reviews;