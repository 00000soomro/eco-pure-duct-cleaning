import React, { useState } from 'react';
import { Menu, X, Phone, Leaf } from 'lucide-react';
import PhoneModal from './PhoneModal';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const phoneNumber = '647-317-4194';

  return (
    <>
      <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-slate-300 px-4 sm:px-10 py-4 bg-white shadow-sm">
      <div className="flex items-center gap-4 text-slate-900">
        <div className="w-8 h-8 text-emerald-600 flex-shrink-0">
          <Leaf className="w-full h-full" />
        </div>
        <h2 className="text-slate-900 text-xl font-bold leading-tight tracking-[-0.015em]">
          EcoPure Duct Cleaning
        </h2>
      </div>
      
      {/* Desktop Navigation */}
      <div className="hidden lg:flex flex-1 justify-end gap-6">
        <nav className="flex items-center gap-8">
          <a 
            className="text-slate-900 text-sm font-medium leading-normal hover:text-blue-600 transition-colors duration-200" 
            href="#services"
          >
            Services
          </a>
          <a 
            className="text-slate-900 text-sm font-medium leading-normal hover:text-blue-600 transition-colors duration-200" 
            href="#pricing"
          >
            Pricing
          </a>
          <a 
            className="text-slate-900 text-sm font-medium leading-normal hover:text-blue-600 transition-colors duration-200" 
            href="#about"
          >
            About Us
          </a>
          <a 
            className="text-slate-900 text-sm font-medium leading-normal hover:text-blue-600 transition-colors duration-200" 
            href="#service-areas"
          >
            Service Areas
          </a>
        </nav>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setIsPhoneModalOpen(true)}
            className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-md h-10 px-4 bg-emerald-600 text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-emerald-700 transition-all duration-200 transform hover:scale-105"
          >
            <span className="truncate">Get a Quote</span>
          </button>
          <button 
            onClick={() => setIsPhoneModalOpen(true)}
            className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-md h-10 bg-transparent text-slate-900 gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-2.5 border border-slate-200 hover:bg-emerald-50 transition-colors duration-200"
          >
            <Phone className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile Menu Button */}
      <div className="lg:hidden">
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="p-2 text-slate-900 hover:text-emerald-600 transition-colors"
        >
          {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white border-b border-slate-300 shadow-lg lg:hidden z-50">
          <nav className="flex flex-col p-4 gap-4">
            <a 
              className="text-slate-900 text-sm font-medium py-2 hover:text-emerald-600 transition-colors" 
              href="#services"
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </a>
            <a 
              className="text-slate-900 text-sm font-medium py-2 hover:text-emerald-600 transition-colors" 
              href="#pricing"
              onClick={() => setIsMenuOpen(false)}
            >
              Pricing
            </a>
            <a 
              className="text-slate-900 text-sm font-medium py-2 hover:text-emerald-600 transition-colors" 
              href="#about"
              onClick={() => setIsMenuOpen(false)}
            >
              About Us
            </a>
            <a 
              className="text-slate-900 text-sm font-medium py-2 hover:text-emerald-600 transition-colors" 
              href="#service-areas"
              onClick={() => setIsMenuOpen(false)}
            >
              Service Areas
            </a>
            <div className="flex gap-2 pt-2">
              <button 
                onClick={() => setIsPhoneModalOpen(true)}
                className="flex-1 bg-emerald-600 text-white py-2 px-4 rounded-md font-bold text-sm hover:bg-emerald-700 transition-colors"
              >
                Get a Quote
              </button>
              <button 
                onClick={() => setIsPhoneModalOpen(true)}
                className="p-2 border border-slate-200 rounded-md hover:bg-emerald-50 transition-colors"
              >
                <Phone className="w-4 h-4" />
              </button>
            </div>
          </nav>
        </div>
      )}
      </header>
      
      <PhoneModal 
        isOpen={isPhoneModalOpen}
        onClose={() => setIsPhoneModalOpen(false)}
        phoneNumber={phoneNumber}
      />
    </>
  );
};

export default Header;